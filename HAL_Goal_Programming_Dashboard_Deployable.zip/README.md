# HAL Goal Programming Dashboard

### Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

### Deploy publicly
Upload `app.py` and `requirements.txt` to a GitHub repository and deploy the repository through Streamlit Community Cloud.

The app is self-contained: the dashboard data is embedded in `app.py`, so no Excel file is required for deployment.
